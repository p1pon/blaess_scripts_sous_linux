#! /usr/bin/perl -w

open STDOUT, "|sort";
print <>;
close STDOUT;

