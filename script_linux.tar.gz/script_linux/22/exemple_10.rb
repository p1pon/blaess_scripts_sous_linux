#! /usr/local/bin/ruby

include Math

print "PI = #{PI}\n"
print "4 * atan2 (1,0) = #{ 4 * atan2 (1,0) }\n"

