#! /usr/bin/perl -w

use strict;
use Module03;

print "$var_exportable\n";
print "@tab_exportable\n";
