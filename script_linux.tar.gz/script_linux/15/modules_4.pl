#! /usr/bin/perl -w

use Module03;
fct_exportable();
