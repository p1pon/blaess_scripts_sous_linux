#! /usr/bin/perl -w

use Module01;

sub BEGIN
{
	print "Routine BEGIN de modules_1.pl\n";
}

sub END
{
	print "Routine END de modules_1.pl\n";
}

	print "Ex�cution de modules_1.pl\n";
