sub BEGIN {
	print "Routine BEGIN (1) de Module02.pm\n";
}

sub END {
	print "Routine END (1) de Module02.pm\n";
}

sub BEGIN {
	print "Routine BEGIN (2) de Module02.pm\n";
}

sub END {
	print "Routine END (2) de Module02.pm\n";
}

	return 1;
