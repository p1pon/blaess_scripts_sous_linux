BEGIN {
	print "Routine BEGIN de Module01\n";
}

END {
	print "Routine END de Module01\n";
}

use Module02;

	return 1;
