#! /usr/bin/perl -w

use strict;
use Module03;

fct_exportee();
print "$var_exportee\n";
print "@tab_exportee\n";
