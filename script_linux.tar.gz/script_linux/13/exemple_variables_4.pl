#! /usr/bin/perl -w

use strict;

my $latitude = 0.5;
$lattitude = 2 * ($latitude - 1);
$lattitude += 10;
print "latitude = $latitude\n";

