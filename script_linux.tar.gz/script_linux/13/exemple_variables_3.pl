#! /usr/bin/perl -w

$latitude = 0.5;
$lattitude = 2 * ($latitude - 1);
$lattitude += 10;
print "latitude = $latitude\n";

