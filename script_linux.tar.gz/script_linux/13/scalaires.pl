#! /usr/bin/perl -w

# Affectations de quelques variables

$pi = 3.1415926535;

$pi_sur_2 = $pi / 2;

$mnemo_pi = "Que j'aime a faire apprendre ce nombre utile aux sages";

print $mnemo_pi;
print "\n";
print $pi;
print "\n";
print $pi_sur_2;
print "\n";
