#! /usr/bin/python

from vecteur import Vecteur

v1 = Vecteur (1.1, 2.2, 3.3)
v2 = Vecteur (4.4, 5.5, 6.6)

print v1, "+", v2, "=", v1 + v2
