#! /usr/bin/python

def fonction_1 () :
	print "Fonction 1 de module 1"

variable_1 = 123

print "Le module 1 vient de d�marrer"
