#! /bin/sh

for i in 1 2 3 5 7 11 13 ; do
	echo "$i� = $((i * i))"
done
