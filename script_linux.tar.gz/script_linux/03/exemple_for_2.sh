#! /bin/sh

for i ; do
	echo $i
done
